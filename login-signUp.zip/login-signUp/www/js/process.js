

let process = {
	main:function() {
		let content = 
		<div class="buttonsDIV">
		<div class="signUp-div">
			<button class="signup-btn" onclick={SignUp} id="SUP">Sign Up</button>
		</div>
		<div class="logIn-div">
			<button class="login-btn" onclick={Login} id="LOG">Login</button>
		</div>
	</div>
	<div class="loginDIV" id="loginDIV">
			<br /><br /><br /><br />
			<div><input type="text" placeholder="Username" id="username"/></div>
			<br>
			<div><input type="Password" placeholder="Password" id="Password"/></div>
			<br /><br />
			<div><button class="login-btn-send" onclick={login}>Send</button></div>
	</div>
	<div class="signupDIV" id="signupDIV">
			<br /><br /><br /><br />
			<div><input type="text" placeholder="First name" id="firstN"/></div>
			<br />
			<div><input type="text" placeholder="Last name" id="lastN"/></div>
			<br />
			<div><input type="text" placeholder="Email" id="email">
			<br /><br />
			<input type="Password" placeholder="Password" id="pass"></div>
			<br />
			<input type="Password" placeholder="Confirm Password" id="finalpass">
			<br /><br />
			<div><button class="signup-btn-send" onclick={signup}>Send</button></div>
	</div>;

	ReactDOM.render(content,document.getElementById('root'));
	}
}


process.main();


var idCounter = 0;
var user = [
	firstName = ['Bryan Paulo'],
	lastName = ['Altezo'],
	userName = ['admin'],
	passWord = ['12345'],
	email = ['rukawa426@gmail.com'],
	id = [idCounter]
];


function login() {
	var username = document.getElementById('username').value;
	var password = document.getElementById('Password').value;

	console.log(username,password);

	for (var x = 0; x < id.length; x++){
		if(username === userName[x]){
			if(password === passWord[x]){
				alert("Logged in. Welcome " + username);
			}else{
				alert("Password is incorrect");
			}
		}else if(username != userName[x] && password === passWord[x] || username != userName[x] && password != passWord[x]){
			if(idCounter > 0){
				//nothing here
			}else{
				alert("invalid username or password!");
			}
		}
	}
}

function signup(){
	idCounter += 1;

	var fn = document.getElementById('firstN').value;
	var ln = document.getElementById('lastN').value;
	var eMail = document.getElementById('email').value;
	var pass = document.getElementById('pass').value;
	var finalpass = document.getElementById('finalpass').value;
	
	if(pass != finalpass){
		document.getElementById('pass').setAttribute('style','color:red;');
		alert('password incorrect');
	}else{
		document.getElementById('pass').setAttribute('style','color:black;');	
	
		firstN[idCounter] = fn;
		lastN[idCounter] = ln;
		userName[idCounter] = fn + "2k";
		passWord[idCounter] = finalpass;
		email[idCounter] = eMail;
		id[idCounter] = idCounter;
		alert("Success! You are signed in.");
		alert("Your username is  "+ userName[idCounter] + ".");
		console.log("registered:  " + firstN,lastN,userName,passWord,email);
		
		fn = "";
		ln = "";
		eMail = "";
		pass = "";
		finalpass = "";
	}
}